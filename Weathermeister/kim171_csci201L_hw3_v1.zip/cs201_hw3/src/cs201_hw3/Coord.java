package cs201_hw3;

public class Coord {
	long lon; 
	float lat; 

}
