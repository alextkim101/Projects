package cs201_hw3;

public class CustomException extends Exception{
	/**
	 * 
	 */
	private static final long serialVersionUID = -5901896961994224550L;

	public CustomException(String message)
	  {
	    super(message);
	  }
}
